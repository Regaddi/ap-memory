package de.meyer.androidpraktikum;

import android.app.Activity;

public class SuperActivity extends Activity {
	
}
