package de.meyer.androidpraktikum.lobby;

public class LobbyData {
	private String gameName;
	private String gameHost;
	private int playerQuantity;
	
	@SuppressWarnings("unused")
	private LobbyData () {}
	
	public LobbyData (String gameName, String gameHost, int playerQuantity) {
		this.gameName = gameName;
		this.gameHost = gameHost;
		this.playerQuantity = playerQuantity;
	}
	
	
	/*GETTER AND SETTER - AUTOCREATE*/

	public String getGameName() {
		return gameName;
	}

	public void setGameName(String gameName) {
		this.gameName = gameName;
	}

	public String getGameHost() {
		return gameHost;
	}

	public void setGameHost(String gameHost) {
		this.gameHost = gameHost;
	}

	public int getPlayerQuantity() {
		return playerQuantity;
	}

	public void setPlayerQuantity(int playerQuantity) {
		this.playerQuantity = playerQuantity;
	}
	
	
	

}
