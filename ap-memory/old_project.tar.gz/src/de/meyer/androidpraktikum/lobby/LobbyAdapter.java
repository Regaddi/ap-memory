package de.meyer.androidpraktikum.lobby;

public class LobbyAdapter {

}
