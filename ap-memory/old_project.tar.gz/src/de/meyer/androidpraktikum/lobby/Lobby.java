package de.meyer.androidpraktikum.lobby;

import android.os.Bundle;
import de.meyer.androidpraktikum.R;
import de.meyer.androidpraktikum.SuperActivity;

public class Lobby extends SuperActivity {
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.lobby);
	}
}
