package de.meyer.androidpraktikum;

public class Register extends SuperActivity {

}
