package de.meyer.androidpraktikum;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Main extends Activity {
	private ImageButton singlePlayerButton;
	private ImageButton multiPlayerButton;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        // initialisieren
        singlePlayerButton = (ImageButton) findViewById(R.id.btn_singleplayer);
        multiPlayerButton = (ImageButton) findViewById(R.id.btn_multiplayer);
        
        
        
        
    }
    
    public void onButtonClick (final View view) {
    	switch (view.getId()) {
    	case R.id.btn_singleplayer:
    		break;
    	case R.id.btn_multiplayer:
    		try {
	    		Intent i = new Intent(this, Login.class);
	    		startActivity(i);
    		} catch(Exception e) {
    			e.printStackTrace();
    		}
    		break;
    	}
    }
}