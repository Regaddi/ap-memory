package de.meyer.androidpraktikum;

public class PersonalStats extends SuperActivity {

}
