package de.meyer.androidpraktikum;

public class CurrentScore extends SuperActivity {

}
