package de.meyer.androidpraktikum;

public class Player {

}
