package de.meyer.androidpraktikum;

import org.apache.http.client.methods.HttpGet;

import de.meyer.androidpraktikum.lobby.Lobby;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Login extends SuperActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
	}

	public void onButtonClick(View v) {
		switch(v.getId()) {
		case R.id.btn_login_user:
			EditText ed_user = (EditText)findViewById(R.id.ed_login_user);
			EditText ed_pass = (EditText)findViewById(R.id.ed_password_user);
			
			String user = ed_user.getText().toString();
			String pass = ed_pass.getText().toString();
			
			HttpGet http_login = new HttpGet(R.string.app_url + "?action=login&user=" + user + "&pass=" + pass);
			Intent success = new Intent(this, Lobby.class);
			
			new HttpAsyncTask(http_login, this, success);
		}
	}
}
